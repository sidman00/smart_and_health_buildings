RSSI_TABLE_EQUATION.jpg : Has table measurments and derived equation. 

localization_results : One time run, same beacons used in localization algorithm. 

localization_results_final : Multiple runs. Algorithm runs three times, with different beacons on each run depending on which got picked up first. Results are displayed as follows : 

[[[1.35127, 5.85967], {'<Address c2007d000078>': [31.71, 26.85], '<Address c2007d00008f>': [31.45, 24.16]}]

Where the first field is the localized x,y coordinate result of the microbit. The second field is C1 and its x,y coordinates and the third field is C2 and its x,y cooridnates.  

